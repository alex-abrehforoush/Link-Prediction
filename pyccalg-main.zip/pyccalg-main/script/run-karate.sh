python ./src/pyccalg.py -d ./data/karate.tsv -r 20,23 -a 0.5 -s scipy -m charikar >./results/karate.txt
